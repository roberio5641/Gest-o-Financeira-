package com.example.gestaofinaceira.adpter

import android.view.View

interface ReceitaListener {

    fun onItemClickListenerR(view: View, position: Int)

    fun onItemLongClickListenerR(view: View, position: Int)

}