package com.example.gestaofinaceira.adpter

import android.view.View

interface DespesaListener {

    fun onItemClickListenerD(view: View, position: Int)

    fun onItemLongClickListenerD(view: View, position: Int)

}